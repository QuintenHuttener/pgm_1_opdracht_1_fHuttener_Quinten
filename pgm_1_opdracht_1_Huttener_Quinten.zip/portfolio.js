const portfolio = {
    project: [
      {
        title: "SKIVE",
        synopsis: "Webdevelopment / App Development",
        thumbnailUrl: "https://dl.airtable.com/.attachments/701dd616bd7a4a4298b077b9c79ffe56/15aeeb50/Schermafbeelding2020-05-16om09.47.11.png",
        assets: [
            {title:"SKIVE-image 001" , type:"image", sourceUrl:"https://dl.airtable.com/.attachments/24b31d875c54dabf3e1c0db2ba01f2ae/5e55d2c8/Schermafbeelding2020-05-16om09.49.28.png"},
            {title:"SKIVE-image 002", type:"image", sourceUrl:"https://dl.airtable.com/.attachments/2887017db73fe88028b75fb8d34d8477/ec1ab497/Schermafbeelding2020-05-16om09.49.37.png"},
            {title:"SKIVE-image 003", type:"image", sourceUrl:"https://dl.airtable.com/.attachments/9d8194be37055a6d51b3a0e20b95daf0/3da1cd4d/Schermafbeelding2020-05-15om09.25.03.png"}
        ],
        likes: Math.floor(Math.random()*100),
        views: Math.floor(Math.random()*1000),
        messageDate: "12 Augustus 2020, 08:03",
        modDate: "12 Augustus 2020, 10:04"
      },
      {
        title: "EUROPEAN MARINE BOARD",
        synopsis: "Brand Design / Book / infographic / Design Thinking / Digitaal",
        thumbnailUrl: "https://dl.airtable.com/.attachments/3cf563b4d87744043d513fc61a826f67/8f0c87b7/Kni2psel.JPG",
        assets: [
            {title:"EUROPEAN-MARINE-BOARD-image 001", type:"Image", sourceUrl:"https://dl.airtable.com/.attachments/3cf563b4d87744043d513fc61a826f67/8f0c87b7/Kni2psel.JPG"},
            ],
        likes: Math.floor(Math.random()*100),
        views: Math.floor(Math.random()*1000),
        messageDate: "25 juli 2020, 20:12",
        modDate: "25 juli 2020, 21:59"
      }
    ]
  };


function convertAssets(assets){
    let assetStr ='';
    assets.forEach(function (asset, ind){
        assetStr +=`*Title: ${asset.title}\n`
        assetStr +=`(*Type: ${asset.type})\n  `
        assetStr +=`*Source: ${asset.sourceUrl}`
    });
    return assetStr;
}

  function convertProjects(project) {
    let tempStr = '';
    project.forEach(function (ing, index) {
        tempStr += `============================================ ${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-Title: ${ing.title}${index < project.length - 1 ? '\n' : '\n'}`;
        tempStr += `============================================ ${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-Synopsis: ${ing.synopsis}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-thumbnailUrl: ${ing.thumbnailUrl}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-likes: ${ing.likes}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-views: ${ing.views}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-message date: ${ing.messageDate}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-Last modification: ${ing.modDate}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `\n-------------------ASSETS-------------------${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `${convertAssets(ing.assets)}${index < project.length - 1 ? '\n' : '\n'}`
    });
    return tempStr;
  };
  
const msg = `
--------------------------------------------
                    PORTFOLIO
--------------------------------------------

${convertProjects(portfolio.project)}
  `;
  console.log(msg);