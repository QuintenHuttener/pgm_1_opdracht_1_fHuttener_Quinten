const portfolio = {
    project: [
      {
        title: "TENTOONSTELLING ‘CONCERTFOTOGRAFIE’ DOOR GEERT BONNE",
        synopsis: "Geert, voormalig drummer bij Gorky, is een ‘gevoelsmens’. Zijn invalshoek bij het maken van de concertfoto’s, meer bepaald het sub-thema rockfotografie, is het gevoel van passie, geluk, concentratie en overgave dat muziekartiesten ervaren op een podium.",
        body: `<p> “Mijn voorkeur gaat daarbij uit naar zwart-wit foto’s omdat je meer de nadruk kan leggen op het onderwerp”, vertelt Geert. De foto’s zijn getrokken over een tijdsspanne van vijf jaar. In de tentoonstelling zien we onder andere Luc De Vos en Raymond van het Groenewoud passeren. Deze tentoonstelling moet studenten Grafische en Digitale Media inspireren en stimuleren om zelf hun creatieve blik te verruimen.\n
        Toen Geert Bonne als drummer van Gorky afscheid nam van de groep onder leiding van Luc De Vos, verliet hij de muziekwereld niet helemaal. Hij bleef verder deel uitmaken van diverse ensembles en zocht een nieuwe reden om de concertsfeer op te snuiven. Geert vond een nieuwe liefde in concertfotografie. Als rasechte muzikant kende hij dit wereldje als geen ander en wist hij hoe hij zich hierin moest bewegen om de juiste shots in zijn lens te krijgen. De foto’s werden vakkundig geprint door Geert Fasseur, docent aan de opleiding Grafische en Digitale Media in campus Mariakerke. Hij werkte nauw samen met de fotograaf. Beide expertises versterken elkaar en die samenwerking zorgde voor een professioneel eindresultaat. “De foto’s werden geprint op een Canon Pro 4000 en het papier heet Permajet Ultra Pearl. De reden voor dit papier is dat bij het maken van een scan witte stipjes in het beeld zouden verschijnen. Dit papier is dus zeer interessant als beveiliging voor fotografen tegen het kopiëren van hun werk”, vertelt Geert Fasseur. De kleurfoto’s zijn geprint op dibond op een Roland UV LEJ-640.\n
        Fotograferen tijdens een concert is geen sinecure. Geert Bonne legt uit: “concertfotografie moet het doen met het licht dat ter beschikking is, dus dat varieert van goed tot zeer slecht en bijna onbruikbaar licht. Het is altijd een beetje zoeken in het begin maar van zodra de eerste noten van het optreden zijn gespeeld, kan je al inschatten hoe de belichting gedurende het concert zal zijn”. De fotograaf is ook geen fan van het extra belichten. “Ik belicht nooit bij omdat het de sfeer van de bestaande belichting verstoort. Het gebruik van flitslicht ook is zeer storend voor de muzikanten en publiek.” Lichtsterke objectieven zijn bij dit soort omstandigheden een troef. “Ikzelf heb de eerste jaren niet met een lichtsterk objectief (Nikon 18-105mm lens, 3.5-5.6) gewerkt en daarom fotografeerde ik steeds met een hoge ISO-waarde, meestal 6400 en redelijk lange sluitertijden. Maar vertoonden mijn beelden soms ruis en onscherpte. Maar voor mij is het niet de scherpte maar de emotie dat het belangrijkste is in een beeld, zoals de kleurfoto van Elephant in de tentoonstelling”, legt Geert uit. De fotograaf werkt met verschillende lichtsterke objectieven: een Nikon 85mm 1.8, een Nikon 50mm 1.4 en een Nikon 28mm 2.8, met een maximale ISO-waarde van 3200. De sluitertijd bij zijn foto’s varieert tussen 1/125 en 1/500. De foto’s in de tentoonstelling zijn allemaal gefotografeerd met een Nikon d7100 met een Nikon 18-105mm lens, 3.5-5.6.\n
        De foto’s zijn nog te bezichtigen tot 31/01/2020 in de mediatheek op campus Mariakerke. De openingsuren van de mediatheek vindt u hier: (https://www.gdm.gent/”https://www.arteveldehogeschool.be/mediatheek/live/ws/”)https://www.arteveldehogeschool.be/mediatheek/live/ws/\n
        Op 28 november 2019 is fotograaf Titus Simoens te gast op onze campus in teken van Woord over Beeld #19 georganiseerd door de vakgroep fotografie van het KISP. Aansluitend is er de mogelijkheid om het werk van Geert Bonne te bekijken. Info en tickets: https://www.universe.com/events/wob-19-titus-simoens-tickets-M7HSNF?fbclid=IwAR3Efb_hcCP2eXx5ArmNcKWSNEjPMJ_TCyZJlS65fgbM5B1k2_hHf6Wa56c </p>`,
        thumbnailUrl: "https://dl.airtable.com/.attachments/ce0470435c01a2a03365cacb5f70def2/fc368b51/IMG_0521.JPG",
        assets: [
            {title:"Lisa De Wilde", sourceUrl:"https://dl.airtable.com/.attachments/8216307230f675f3fa6eb2aa90474c67/7ff726d6/lisa.jfif"}
        ],
        messageDate: "12 Augustus 2020, 08:03",
        modDate: "12 Augustus 2020, 10:04"
      },
      {
        title: "ERASMUS + PHOTO PROJECT: EEN INTERNATIONALE SAMENWERKING MET LIEFDE VOOR FOTOGRAFIE",
        synopsis: "20 CMO-studenten kregen de kans om gedurende twee jaar om met buitenlandse studenten hun fotografieskills te verbeteren en hun creativiteit op gebied van fotografie te ontplooien samen met buitenlandse docenten. Zowel voor studenten als voor de begeleidende docenten waren de workshops een heel boeiende en leerrijke ervaring.",
        body: `<p> “Een super leuke ervaring waarbij je fotografie maar ook je medestudenten op nieuwe manier leert kennen”, vertelt studente Hannah. Het project Erasmus+ Photo project werd eind 2017 geboren in Gent samen met vier partnerinstellingen uit Nederland, Estland, Letland en Slovakije. Studenten CMO Photo Design hadden de kans deel te nemen aan de eerste workshop in Gent en ook aan de tweede workshop in Slovakije (april 2018). Daarna volgden een workshop in Nederland (oktober 2018), in Letland (maart 2019) en de laatste in Estland (april 2019). Jana Bruggeman getuigt: “Het was een leerrijke week om nooit meer te vergeten, mede dankzij de zalige groep waarmee ik deze reis mocht beleven.” Naast de workshops, werd er ook nog een Studybook en een Virtual Learning Environment (VLE) ontwikkeld. Het ‘studybook’ bevat een twintigtal workshops die docenten fotografie kunnen inspireren om zowel de techniek als creativiteit van studenten te bevorderen. Je kunt de pdf-versie van het’ studybook’ downloaden op de website van het project: https://erasmusphoto.org/. De ‘VLE’ biedt daarenboven extra lesmateriaal, artikels, video’s, … die zowel studenten als docenten fotografie kunnen helpen om nieuwe inzichten te krijgen. Eind augustus liep het project ten einde. Enkele deelnemende studenten die in maart en april 2019 op stap gingen vertellen: Seppe Claes: “Achteraf bekeken weet ik niet waarom ik aan het twijfelen was om me voor deze reis in te schrijven. Ik bekijk de reis als één van de mooiste kansen die ik ooit kreeg. Een hele week aan de slag gaan rond fotografie tijdens leerrijke workshops, gecombineerd met ontspannende momenten tussendoor klinkt voor elke GDM’er volgens mij als muziek in de oren. Snel geraakten we ook als groep aan elkaar gehecht, de vriendschappen die gevormd worden door samen zulke mooie momenten mee te maken zijn onbetaalbaar. Bedankt voor alles en op naar het volgende Europees project.” Hannah De Beir: “Dit jaar kreeg ik de kans om samen met vier medestudenten en één docent op fotoreis te vertrekken naar Estland. Door de begeleidende school en de meereizende docent kreeg ik de kans om veel bij te leren. Op het einde van de week werden enkele prijzen uitgedeeld en werden de werken van alle studenten tentoongesteld. Een super leuke ervaring waarbij je fotografie maar ook je medestudenten op nieuwe manier leert kennen!” Gilles Baetslé: “Ik heb me in deze week echt geamuseerd! De toffe docent en toffe medestudenten hebben hier extra voor gezorgd. Als ik ooit de mogelijkheid heb om zoiets opnieuw te mogen meemaken, ik schrijf me direct in!” Rozalia Monkiewicz: “Onze fotoweek in Letland was een unieke ervaring. We hebben niet enkel nieuwe trucjes geleerd, maar hebben ook vooral nieuwe inzichten gekregen en andere mensen leren kennen. Vooral dat laatste vond ik heel leuk. Dus moest je ooit twijfelen om mee te doen aan zo'n project, gewoon inschrijven want het is een leuke ervaring!” Meer info over het project, de partners en het ontwikkeld materiaal is te vinden op https://erasmusphoto.org/. </p>`,
        thumbnailUrl: "https://dl.airtable.com/.attachments/3cf563b4d87744043d513fc61a826f67/8f0c87b7/Kni2psel.JPG",
        assets: [
            {title:"Lisa De Wilde", sourceUrl:"https://dl.airtable.com/.attachments/8216307230f675f3fa6eb2aa90474c67/7ff726d6/lisa.jfif"},
            ],
        messageDate: "25 juli 2020, 20:12",
        modDate: "25 juli 2020, 21:59"
      }
    ]
  };


function convertAssets(assets){
    let assetStr ='';
    assets.forEach(function (asset, ind){
        assetStr +=`*Author: ${asset.title}\n`
        assetStr +=`*Source: ${asset.sourceUrl}`
    });
    return assetStr;
}

  function convertProjects(project) {
    let tempStr = '';
    project.forEach(function (ing, index) {
        tempStr += `============================================ ${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-Post: ${ing.title}${index < project.length - 1 ? '\n' : '\n'}`;
        tempStr += `============================================ ${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-Synopsis: ${ing.synopsis}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-Body: ${ing.body}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-thumbnailUrl: ${ing.thumbnailUrl}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-message date: ${ing.messageDate}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `-Last modification: ${ing.modDate}${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `\n-------------------AUTHORS-------------------${index < project.length - 1 ? '\n' : '\n'}`
        tempStr += `${convertAssets(ing.assets)}${index < project.length - 1 ? '\n' : '\n'}`
    });
    return tempStr;
  };
  
const msg = `
--------------------------------------------
                    News
--------------------------------------------

${convertProjects(portfolio.project)}
  `;
  console.log(msg);